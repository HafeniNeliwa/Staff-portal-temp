import message from './assets/msg.png'
import './index.css'

function MessageFloat(){
    return(
        
          <div className='messagingsection'>
               <img src={message}></img>
           </div>
    
    );
}
export default MessageFloat