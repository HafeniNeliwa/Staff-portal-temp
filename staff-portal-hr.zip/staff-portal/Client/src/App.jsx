import './index.css'
import HRhome from './HRhome'
import HRProfile from './HRProfile.jsx'
import HRLeaverequests from './HRLeaverequests.jsx'
import HROvertimerequests from './HROvertimerequests.jsx'
import {BrowserRouter, Routes, Route} from 'react-router-dom'

function App() {
    return(
      <>
      <BrowserRouter>
      <Routes>
        <Route index element= {<HRhome/>}/>
        <Route path='/home' element={<HRhome/>}/>
        <Route path='/employees' element={<HRProfile/>}/>
        <Route path='/leaverequests' element={<HRLeaverequests/>}/>
        <Route path='/overtimerequests' element={<HROvertimerequests/>}/>

      </Routes>
      </BrowserRouter>
      </>
    );
}

export default App
