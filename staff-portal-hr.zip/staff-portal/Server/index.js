const express = require('express')
const app = express()

app.listen(5173 , ()=>{
    console.log("server running yes")
})